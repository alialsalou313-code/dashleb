# Deploy Dash Lebanon to Vercel

This project serves the storefront from `public/` and the API from `/api`. The same API handler can also run on Netlify; `_redirects` maps `/api` there.

## Create the Vercel deployment

1. Import this project into Vercel from its Git repository, or use the Vercel CLI from this project folder. Vercel reads `vercel.json`, runs `npm run build`, publishes `public/`, and deploys `api/index.mjs` as a Node.js Function.
2. Add these Production environment variables in Project Settings → Environment Variables:
   - `DATABASE_URL`: PostgreSQL connection string from a Vercel Postgres-compatible provider (for example Neon).
   - `SESSION_SECRET`: a new random secret with at least 32 bytes. Keep it private.
   - `APP_URL`: the production site URL, for example `https://dashleb.vercel.app`.
3. Deploy once to create the site URL. Set `APP_URL` to that URL and redeploy if it changed.

## Initialize and import the database

1. Apply the PostgreSQL schema once from this project folder by running `npm run db:schema` with `DATABASE_URL` set to the production database connection string.
2. Start XAMPP MySQL. Set `DATABASE_URL` and `APP_URL` in the same local terminal. If needed, also set `MYSQL_HOST`, `MYSQL_PORT`, `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_DATABASE`, and `XAMPP_UPLOADS_DIR`.
3. Run `npm run migrate:mysql`. The importer transfers database rows and local uploads. It intentionally skips old password reset tokens and does not carry over the Gmail App Password; re-enter the mail credentials in Admin Settings after import.

Do not commit database URLs, `SESSION_SECRET`, or mail passwords. A live deployment cannot serve customer and admin data until the PostgreSQL schema and imported data are present.
