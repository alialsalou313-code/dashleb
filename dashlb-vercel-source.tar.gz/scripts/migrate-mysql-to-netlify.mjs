import mysql from 'mysql2/promise';
import pg from 'pg';
import fs from 'node:fs/promises';
import path from 'node:path';

const { Pool } = pg;
const tables = ['users','profiles','settings','categories','products','product_images','wishlists','delivery_locations','orders','order_items','reviews','points_history','contact_messages','coupons','coupon_redemptions','ai_settings','ai_public_settings','mail_settings'];
const conflict = { wishlists:'user_id,product_id', delivery_locations:'user_id', settings:'id', ai_settings:'id', ai_public_settings:'id', mail_settings:'id' };
const databaseUrl = process.env.DATABASE_URL || process.env.POSTGRES_URL || process.env.NETLIFY_DB_URL;
if (!databaseUrl) throw new Error('Set DATABASE_URL to the connected PostgreSQL database before importing.');
const mysqlConn = await mysql.createConnection({
  host: process.env.MYSQL_HOST || '127.0.0.1',
  port: Number(process.env.MYSQL_PORT || 3306),
  user: process.env.MYSQL_USER || 'root',
  password: process.env.MYSQL_PASSWORD || '',
  database: process.env.MYSQL_DATABASE || 'dash_lebanon'
});
const db = new Pool({ connectionString: databaseUrl, ssl: { rejectUnauthorized: false }, max: 2 });
const appUrl = (process.env.APP_URL || '').replace(/\/$/, '');
const uploadsRoot = process.env.XAMPP_UPLOADS_DIR || 'C:/xampp/htdocs/dash-lebanon/uploads';
const imageFields = {
  settings: ['logo_url','favicon_url'],
  categories: ['image_url'],
  products: ['cover_image'],
  product_images: ['url']
};

async function moveAsset(value) {
  if (typeof value !== 'string' || !value) return value;
  let pathname;
  try { pathname = new URL(value, 'http://localhost').pathname; } catch { return value; }
  const marker = '/uploads/';
  const at = pathname.indexOf(marker);
  if (at < 0) return value;
  const rel = decodeURIComponent(pathname.slice(at + marker.length));
  const [bucket, ...parts] = rel.split('/');
  const key = parts.join('/');
  if (!bucket || !key || key.split('/').includes('..')) return value;
  try {
    const data = await fs.readFile(path.join(uploadsRoot, bucket, key));
    const ext = path.extname(key).slice(1).toLowerCase();
    const mime = ({jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif',avif:'image/avif',webm:'audio/webm',ogg:'audio/ogg',mp3:'audio/mpeg'})[ext] || 'application/octet-stream';
    await db.query('INSERT INTO storage_objects(bucket,path,mime,data) VALUES($1,$2,$3,$4) ON CONFLICT(bucket,path) DO UPDATE SET mime=EXCLUDED.mime,data=EXCLUDED.data', [bucket,key,mime,data]);
    return appUrl + '/api?storage=' + encodeURIComponent(bucket + '/' + key);
  } catch (e) {
    if (e.code === 'ENOENT') return value;
    throw e;
  }
}

async function transform(table, original) {
  const row = { ...original };
  if (table === 'mail_settings') {
    row.smtp_app_password = '';
    if (appUrl) row.app_url = appUrl;
  }
  for (const field of imageFields[table] || []) row[field] = await moveAsset(row[field]);
  return row;
}

try {
  for (const table of tables) {
    const [rows] = await mysqlConn.query('SELECT * FROM ' + table);
    for (const original of rows) {
      const row = await transform(table, original);
      const cols = Object.keys(row);
      const values = cols.map(k => row[k]);
      const marks = cols.map((_, i) => '$' + (i + 1));
      const key = (conflict[table] || 'id').split(',');
      let sql = 'INSERT INTO "' + table + '" (' + cols.map(c => '"' + c + '"').join(',') + ') VALUES (' + marks.join(',') + ') ON CONFLICT (' + key.map(k => '"' + k + '"').join(',') + ') ';
      const updates = cols.filter(c => !key.includes(c));
      sql += updates.length ? 'DO UPDATE SET ' + updates.map(c => '"' + c + '"=EXCLUDED."' + c + '"').join(',') : 'DO NOTHING';
      await db.query(sql, values);
    }
    console.log('Imported ' + table + ': ' + rows.length + ' rows');
  }
  for (const table of ['product_images','wishlists','order_items','points_history','coupon_redemptions']) {
    await db.query("SELECT setval(pg_get_serial_sequence('" + table + "','id'), GREATEST(COALESCE((SELECT MAX(id) FROM \"" + table + "\"),1),1), true)");
  }
  console.log('Import complete. Password reset tokens and the Gmail App Password were not copied.');
} finally {
  await mysqlConn.end();
  await db.end();
}
