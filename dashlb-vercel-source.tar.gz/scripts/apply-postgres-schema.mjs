import pg from 'pg';
import fs from 'node:fs/promises';

const connectionString = process.env.DATABASE_URL || process.env.POSTGRES_URL || process.env.NETLIFY_DB_URL;
if (!connectionString) throw new Error('Set DATABASE_URL to your PostgreSQL connection string first.');
const sql = await fs.readFile(new URL('../netlify/database/migrations/001_initial.sql', import.meta.url), 'utf8');
const pool = new pg.Pool({ connectionString, ssl: { rejectUnauthorized: false }, max: 1 });
try {
  await pool.query(sql);
  console.log('PostgreSQL schema applied.');
} finally {
  await pool.end();
}
