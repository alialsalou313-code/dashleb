import fs from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const publish = path.join(root, 'public');
const assets = 'Dash Lebanon _ Everyday products, delivered fast._files';
await fs.mkdir(publish, { recursive: true });
await fs.copyFile(path.join(root, 'index.html'), path.join(publish, 'index.html'));
await fs.copyFile(path.join(root, 'reset-password.html'), path.join(publish, 'reset-password.html'));
await fs.copyFile(path.join(root, '_redirects'), path.join(publish, '_redirects'));
await fs.cp(path.join(root, assets), path.join(publish, assets), {
  recursive: true,
  filter: source => !source.endsWith('.download')
});
console.log('Built static site files into public/.');
