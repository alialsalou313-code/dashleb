import { chmod } from 'node:fs/promises';

// Netlify scans the functions directory after the build command. Ensure the
// directory is traversable in Linux build images before that scan happens.
for (const path of ['netlify', 'netlify/functions']) {
  await chmod(path, 0o755);
}
