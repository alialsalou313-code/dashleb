CREATE DATABASE IF NOT EXISTS dash_lebanon CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dash_lebanon;

CREATE TABLE IF NOT EXISTS users (
 id CHAR(36) PRIMARY KEY, email VARCHAR(190) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS profiles (
 id CHAR(36) PRIMARY KEY, email VARCHAR(190) NOT NULL, first_name VARCHAR(100) NOT NULL DEFAULT '', last_name VARCHAR(100) NOT NULL DEFAULT '',
 username VARCHAR(80) NULL UNIQUE, phone VARCHAR(40) NULL, role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
 account_status ENUM('enabled','disabled','banned') NOT NULL DEFAULT 'enabled', loyalty_points INT NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_profiles_user FOREIGN KEY(id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS settings (
 id INT PRIMARY KEY DEFAULT 1, store_name VARCHAR(160) NOT NULL DEFAULT 'Dash Lebanon', currency_rate DECIMAL(12,2) NOT NULL DEFAULT 90000,
 hero_title VARCHAR(255) NULL, hero_subtitle TEXT NULL, announcement TEXT NULL, points_per_dollar DECIMAL(8,2) NOT NULL DEFAULT 7,
 cancel_fee DECIMAL(8,2) NOT NULL DEFAULT 4, free_cancel_hours INT NOT NULL DEFAULT 24, whatsapp_number VARCHAR(40) NULL,
 whatsapp_handle VARCHAR(100) NULL, contact_email VARCHAR(190) NULL, instagram_url TEXT NULL, instagram_handle VARCHAR(100) NULL,
 facebook_url TEXT NULL, facebook_handle VARCHAR(100) NULL, tiktok_url TEXT NULL, tiktok_handle VARCHAR(100) NULL,
 logo_url TEXT NULL, favicon_url TEXT NULL, page_visibility JSON NULL
);
CREATE TABLE IF NOT EXISTS categories (
 id CHAR(36) PRIMARY KEY, name VARCHAR(150) NOT NULL, slug VARCHAR(160) NOT NULL UNIQUE, description TEXT NULL,
 image_url TEXT NULL, sort_order INT NOT NULL DEFAULT 0, is_active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
 id CHAR(36) PRIMARY KEY, category_id CHAR(36) NULL, name VARCHAR(255) NOT NULL, description TEXT NULL,
 price DECIMAL(12,2) NOT NULL DEFAULT 0, compare_at_price DECIMAL(12,2) NULL, delivery_price DECIMAL(12,2) NOT NULL DEFAULT 0,
 bundle_qty INT NULL, bundle_price DECIMAL(12,2) NULL, specifications JSON NULL, rating_avg DECIMAL(3,2) NULL, rating_count INT NOT NULL DEFAULT 0,
 stock INT NOT NULL DEFAULT 0, sku VARCHAR(100) NULL, cover_image TEXT NULL, is_active BOOLEAN NOT NULL DEFAULT TRUE, is_featured BOOLEAN NOT NULL DEFAULT FALSE,
 is_bundle BOOLEAN NOT NULL DEFAULT FALSE, bundle_items JSON NULL, points_reward INT NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_products_active(is_active), INDEX idx_products_category(category_id),
 CONSTRAINT fk_products_category FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS product_images (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, product_id CHAR(36) NOT NULL, url TEXT NOT NULL, sort_order INT NOT NULL DEFAULT 0,
 CONSTRAINT fk_product_images_product FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS wishlists (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id CHAR(36) NOT NULL, product_id CHAR(36) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_wishlist(user_id,product_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS delivery_locations (
 user_id CHAR(36) PRIMARY KEY, city VARCHAR(150) NULL, district VARCHAR(150) NULL, full_address TEXT NULL,
 latitude DECIMAL(10,7) NULL, longitude DECIMAL(10,7) NULL, source VARCHAR(40) NULL, confirmed_at DATETIME NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS orders (
 id CHAR(36) PRIMARY KEY, order_number VARCHAR(40) NOT NULL UNIQUE, user_id CHAR(36) NULL,
 name VARCHAR(200) NOT NULL, phone VARCHAR(40) NOT NULL, phone2 VARCHAR(40) NULL, city VARCHAR(150) NOT NULL,
 district VARCHAR(150) NULL, address TEXT NOT NULL, floor VARCHAR(80) NULL, notes TEXT NULL,
 subtotal DECIMAL(12,2) NOT NULL DEFAULT 0, delivery_fee DECIMAL(12,2) NOT NULL DEFAULT 4,
 discount DECIMAL(12,2) NOT NULL DEFAULT 0, total DECIMAL(12,2) NOT NULL DEFAULT 0, coupon_code VARCHAR(80) NULL,
 status VARCHAR(40) NOT NULL DEFAULT 'pending', cancel_reason TEXT NULL, points_earned INT NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_orders_user(user_id), INDEX idx_orders_created(created_at),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS order_items (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, order_id CHAR(36) NOT NULL, product_id CHAR(36) NULL,
 product_name VARCHAR(255) NOT NULL, qty INT NOT NULL, price DECIMAL(12,2) NOT NULL,
 is_bundle BOOLEAN NOT NULL DEFAULT FALSE, FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS reviews (
 id CHAR(36) PRIMARY KEY, product_id CHAR(36) NOT NULL, user_id CHAR(36) NOT NULL,
 rating TINYINT NOT NULL, comment TEXT NULL, status VARCHAR(30) NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS points_history (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id CHAR(36) NOT NULL, points INT NOT NULL, note VARCHAR(255) NULL, description VARCHAR(255) NULL,
 order_id CHAR(36) NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS contact_messages (
 id CHAR(36) PRIMARY KEY, name VARCHAR(200) NOT NULL, phone VARCHAR(40) NOT NULL, message TEXT NULL,
 voice_path TEXT NULL, voice_mime VARCHAR(100) NULL, voice_duration_ms INT NULL, is_read BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS coupons (
 id CHAR(36) PRIMARY KEY, code VARCHAR(80) NOT NULL UNIQUE, description VARCHAR(255) NULL,
 discount_type ENUM('fixed','percent') NOT NULL DEFAULT 'fixed', discount_value DECIMAL(12,2) NOT NULL DEFAULT 0,
 min_subtotal DECIMAL(12,2) NOT NULL DEFAULT 0, max_discount DECIMAL(12,2) NULL, max_uses INT NULL,
 max_uses_per_user INT NULL, used_count INT NOT NULL DEFAULT 0, starts_at DATETIME NULL, expires_at DATETIME NULL,
 is_active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS coupon_redemptions (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, coupon_id CHAR(36) NOT NULL, user_id CHAR(36) NULL, order_id CHAR(36) NULL,
 code VARCHAR(80) NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(coupon_id) REFERENCES coupons(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS ai_settings (
 id INT PRIMARY KEY DEFAULT 1, enabled BOOLEAN NOT NULL DEFAULT FALSE, provider VARCHAR(80) NULL, api_key TEXT NULL,
 api_url TEXT NULL, model_name VARCHAR(160) NULL, system_instructions TEXT NULL, allowed_topics TEXT NULL, restricted_topics TEXT NULL,
 temperature DECIMAL(3,2) NOT NULL DEFAULT 0.4, max_tokens INT NOT NULL DEFAULT 700, model VARCHAR(160) NULL, assistant_name VARCHAR(100) NULL, system_prompt TEXT NULL, welcome_message TEXT NULL,
 updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ai_public_settings (
 id INT PRIMARY KEY DEFAULT 1, enabled BOOLEAN NOT NULL DEFAULT FALSE, assistant_name VARCHAR(100) NULL, welcome_message TEXT NULL
);

INSERT IGNORE INTO settings(id,store_name,currency_rate,hero_title,hero_subtitle,points_per_dollar,cancel_fee,free_cancel_hours,whatsapp_number,page_visibility)
VALUES(1,'Dash Lebanon',90000,'Everyday products, delivered fast.','Quality home, kitchen & beauty finds — cash on delivery, anywhere in Lebanon.',7,4,24,'96181877323',JSON_OBJECT('home',true,'offers',true,'wishlist',true,'orders',true,'points',true,'account',true,'contact',true));
INSERT IGNORE INTO ai_public_settings(id,enabled,assistant_name,welcome_message) VALUES(1,FALSE,'المساعد الذكي','اسألني أي شيء عن المتجر.');
INSERT IGNORE INTO ai_settings(id,enabled,provider,model_name,assistant_name,welcome_message) VALUES(1,FALSE,'openai','','المساعد الذكي','اسألني أي شيء عن المتجر.');

CREATE TABLE IF NOT EXISTS password_reset_tokens (email VARCHAR(190) PRIMARY KEY, token_hash CHAR(64) NOT NULL, expires_at DATETIME NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS mail_settings (id INT PRIMARY KEY DEFAULT 1, sender_email VARCHAR(190) NOT NULL, smtp_username VARCHAR(190) NOT NULL, smtp_app_password VARCHAR(255) NOT NULL DEFAULT '', smtp_host VARCHAR(190) NOT NULL DEFAULT 'smtp.gmail.com', smtp_port INT NOT NULL DEFAULT 587, app_url VARCHAR(255) NOT NULL DEFAULT 'http://localhost/dash-lebanon', reset_subject VARCHAR(200) NOT NULL DEFAULT 'Reset your Dash Lebanon password', reset_message TEXT NULL, reset_ttl_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 30);
INSERT IGNORE INTO mail_settings(id,sender_email,smtp_username,smtp_app_password,smtp_host,smtp_port,app_url) VALUES(1,'alialsalou313@gmail.com','alialsalou313@gmail.com','','smtp.gmail.com',587,'http://localhost/dash-lebanon');
