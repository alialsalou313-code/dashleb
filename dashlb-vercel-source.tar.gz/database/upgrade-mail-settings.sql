-- Run once on an existing Dash Lebanon MySQL database. Adds editable password reset email settings.
ALTER TABLE mail_settings
  ADD COLUMN reset_subject VARCHAR(200) NOT NULL DEFAULT 'Reset your Dash Lebanon password',
  ADD COLUMN reset_message TEXT NULL,
  ADD COLUMN reset_ttl_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 30;
