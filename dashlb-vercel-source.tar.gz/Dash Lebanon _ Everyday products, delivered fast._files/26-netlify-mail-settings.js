/* Editable reset email settings for both the PHP and Netlify APIs. */
(() => {
  const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[ch]);
  const draw = window.drawAdminSettingsV2;
  if (typeof draw !== 'function') return;

  window.drawAdminSettingsV2 = function (main) {
    draw(main);
    const card = [...main.querySelectorAll('.card')].find(node =>
      node.querySelector('.panel-kicker')?.textContent.trim() === 'Password reset email'
    );
    if (!card) return;
    const m = window._adminMail || {};
    card.innerHTML =
      '<div class="panel-kicker">Password reset email</div>' +
      '<div class="form-title">Reset link settings</div>' +
      '<div class="muted-note" style="margin-bottom:10px">A reset email is sent only if the address belongs to an account. The reply is the same either way.</div>' +
      '<div class="fgroup"><label class="flabel">Sender email</label><input class="finput" id="mail-sender" type="email" value="' + escapeHtml(m.sender_email || 'alialsalou313@gmail.com') + '"></div>' +
      '<div class="frow2"><div class="fgroup"><label class="flabel">SMTP host</label><input class="finput" id="mail-host" value="' + escapeHtml(m.smtp_host || 'smtp.gmail.com') + '"></div>' +
      '<div class="fgroup"><label class="flabel">SMTP port</label><input class="finput" id="mail-port" type="number" value="' + escapeHtml(m.smtp_port || 587) + '"></div></div>' +
      '<div class="fgroup"><label class="flabel">Website URL used in reset links</label><input class="finput" id="mail-app-url" type="url" value="' + escapeHtml(m.app_url || location.origin) + '"></div>' +
      '<div class="fgroup"><label class="flabel">Email subject</label><input class="finput" id="mail-reset-subject" maxlength="200" value="' + escapeHtml(m.reset_subject || 'Reset your Dash Lebanon password') + '"></div>' +
      '<div class="fgroup"><label class="flabel">Email message</label><textarea class="ftextarea" id="mail-reset-message">' + escapeHtml(m.reset_message || 'We received a request to reset your password. Use the button below to choose a new password.') + '</textarea></div>' +
      '<div class="fgroup"><label class="flabel">Link expiry in minutes (5–1440)</label><input class="finput" id="mail-reset-ttl" type="number" min="5" max="1440" value="' + escapeHtml(m.reset_ttl_minutes || 30) + '"></div>' +
      '<div class="fgroup"><label class="flabel">Gmail App Password</label><input class="finput" id="mail-app-password" type="password" autocomplete="new-password" placeholder="' + (m.has_password ? 'Saved — leave blank to keep' : 'Enter the 16-character app password') + '"></div>' +
      '<div class="muted-note">Status: ' + (m.has_password ? 'Configured' : 'Waiting for App Password') + '</div>' +
      '<div class="muted-note">The email contains a reset button and a copyable fallback link.</div>' +
      '<button class="btn btn-ghost" type="button" style="margin-top:10px" onclick="saveMailSettings()">Save email settings</button>';
  };

  window.saveMailSettings = async function () {
    const get = id => document.getElementById(id)?.value?.trim() || '';
    const password = document.getElementById('mail-app-password')?.value || '';
    const { data, error } = await sb.rpc('admin_save_mail_settings', {
      p_sender_email: get('mail-sender'),
      p_app_password: password || null,
      p_smtp_host: get('mail-host'),
      p_smtp_port: Number(get('mail-port')),
      p_app_url: get('mail-app-url'),
      p_reset_subject: get('mail-reset-subject'),
      p_reset_message: get('mail-reset-message'),
      p_reset_ttl_minutes: Number(get('mail-reset-ttl'))
    });
    if (error) return toast(error.message || 'Could not save email settings');
    window._adminMail = data || window._adminMail;
    document.getElementById('mail-app-password').value = '';
    toast('Password reset email settings saved');
    window.drawAdminSettingsV2(document.getElementById('admin-main'));
  };
})();
