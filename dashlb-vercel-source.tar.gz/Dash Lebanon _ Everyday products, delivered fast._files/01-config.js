/* Local XAMPP REST API configuration */
const DELIVERY_REVERSE_GEOCODING_READY=false;
const sb=window.supabase.createClient();
const AI_FUNCTION_NAME='ai-chat';
