async function doForgot(){
  const email=document.getElementById('fg-email')?.value.trim();
  if(!email)return authMsg('Please enter your email',false);
  const button=document.getElementById('fg-btn');
  button.disabled=true;
  button.innerHTML='<div class="spin"></div>';
  try{
    const response=await fetch('/dash-lebanon/api/request-password-reset.php',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({email})
    });
    const result=await response.json();
    authMsg(result.message||'The request could not be processed.',response.ok);
  }catch(error){
    authMsg('Could not connect to the local server. Please try again.',false);
  }finally{
    button.disabled=false;
    button.textContent='Send reset link';
  }
}
