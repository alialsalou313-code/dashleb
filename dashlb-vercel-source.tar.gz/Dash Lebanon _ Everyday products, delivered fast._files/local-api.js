/* Small Supabase-compatible client for the local PHP REST API. */
(() => {
  const onLocalhost = ['localhost','127.0.0.1'].includes(location.hostname);
  const endpoint = onLocalhost ? '/dash-lebanon/api/index.php' : '/api';
  const publicStorageUrl = (bucket,path) => onLocalhost ? `${endpoint.replace('/api/index.php','')}/uploads/${encodeURIComponent(bucket)}/${String(path).split('/').map(encodeURIComponent).join('/')}` : `${endpoint}?storage=${encodeURIComponent(bucket+'/'+path)}`;
  async function call(payload) {
    const response = await fetch(endpoint, {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
    let result; try { result = await response.json(); } catch { result = {error:{message:'The local API returned an invalid response.'}}; }
    const data=result.data??(payload.route==='auth'&&(result.session||result.user)?result:null);
    return {data, error:result.error ? {message:result.error.message || 'Request failed'} : null, count:result.count ?? data?.__count ?? null};
  }
  class Query {
    constructor(table) { this.table=table; this.op='select'; this.columns='*'; this.rows=[]; this.filters=[]; this.orders=[]; this.max=null; this.one=false; this.head=false; }
    select(columns='*', options={}) { this.columns=columns; this.head=!!options.head; return this; }
    insert(rows) { this.op='insert'; this.rows=rows; return this; }
    upsert(rows) { this.op='upsert'; this.rows=rows; return this; }
    update(row) { this.op='update'; this.rows=[row]; return this; }
    delete() { this.op='delete'; return this; }
    _filter(op,column,value) { this.filters.push({op,column,value}); return this; }
    eq(c,v){return this._filter('eq',c,v)} neq(c,v){return this._filter('neq',c,v)} gt(c,v){return this._filter('gt',c,v)} gte(c,v){return this._filter('gte',c,v)} lt(c,v){return this._filter('lt',c,v)} lte(c,v){return this._filter('lte',c,v)} like(c,v){return this._filter('like',c,v)} ilike(c,v){return this._filter('ilike',c,v)} is(c,v){return this._filter('is',c,v)} in(c,v){return this._filter('in',c,v)}
    order(column, options={}) { this.orders.push({column,ascending:!!options.ascending}); return this; }
    limit(n){this.max=n;return this} single(){this.one=true;return this} maybeSingle(){this.one=true;return this}
    then(resolve,reject){return call({route:'db',table:this.table,op:this.op,columns:this.columns,rows:this.rows,filters:this.filters,order:this.orders,limit:this.max,single:this.one,head:this.head}).then(resolve,reject)}
  }
  const listeners = new Set();
  async function auth(action, data={}) {
    const r=await call({route:'auth',action,...data});
    if(['signIn','signUp','getSession'].includes(action)&&!r.error){
      let value=r.data;
      for(let i=0;i<3&&value&&!value.session&&value.data;i++)value=value.data;
      if(value?.session)r.data=value;
      else if(value?.user?.id)r.data={...value,session:{user:value.user}};
    }
    const session=r.data?.session||null;
    if(!r.error&&(action==='signOut'||(['signIn','signUp'].includes(action)&&session)))listeners.forEach(fn=>{try{fn(action==='signOut'?'SIGNED_OUT':'SIGNED_IN',session)}catch{}});
    return r;
  }
  window.supabase = {createClient: () => ({
    from: table => new Query(table),
    rpc: (name,args={}) => call({route:'rpc',name,args}),
    auth: {
      getSession: async()=>{const r=await auth('getSession');return {data:{session:r.data?.session||null},error:r.error};},
      signInWithPassword: ({email,password})=>auth('signIn',{email,password}),
      signUp: ({email,password,options={}})=>auth('signUp',{email,password,data:options.data||{}}),
      signOut: ()=>auth('signOut'),
      resetPasswordForEmail: (email)=>auth('resetPassword',{email}),
      onAuthStateChange: callback=>{listeners.add(callback);return {data:{subscription:{unsubscribe:()=>listeners.delete(callback)}}};}
    },
    functions:{invoke:async(name,options={})=>{const r=await call({route:'function',name,body:options.body||{}});return r;}},
    storage:{from:bucket=>({
      upload:async(path,file)=>{const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return call({route:'upload',bucket,path,mime:file.type||'application/octet-stream',data:btoa(binary)});},
      getPublicUrl:path=>({data:{publicUrl:publicStorageUrl(bucket,path)}}),
      createSignedUrl:async path=>({data:{signedUrl:publicStorageUrl(bucket,path)},error:null}),
      remove:async paths=>call({route:'remove',bucket,paths})
    })}
  })};
})();
