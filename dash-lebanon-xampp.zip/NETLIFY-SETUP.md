# Netlify backend setup

This project now contains a Netlify Functions API and a PostgreSQL baseline migration. The front end chooses the PHP API on localhost and the Netlify Function on a deployed domain.

## Set up Netlify

1. Connect this project to a Git repository or deploy it with the Netlify CLI. A drag-and-drop static deploy alone does not build serverless functions. The build first ensures the functions folder has readable directory permissions, then publishes only the public/ folder, so PHP and SQL source files stay out of the public site.
2. In the Netlify project, open Data & Storage, create a Netlify Database, and confirm the project is connected to it. The migration under netlify/database/migrations creates the tables during deploy.
3. Add SESSION_SECRET as a private environment variable in Netlify. Use a newly generated random value with at least 32 bytes; do not commit it. The function uses it to sign login cookies and password-reset tokens.
4. Set APP_URL to the production site URL (for example https://dashleb.netlify.app).
5. Deploy the connected project. Netlify installs the package dependencies, applies the migration, and deploys netlify/functions/api.mjs.

## Copy current MySQL data

Start XAMPP MySQL. Set NETLIFY_DB_URL in your local terminal to the connection string for the Netlify Postgres database. APP_URL should be the production site URL. MYSQL_HOST, MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DATABASE default to 127.0.0.1, 3306, root, blank, and dash_lebanon. XAMPP_UPLOADS_DIR defaults to C:/xampp/htdocs/dash-lebanon/uploads.

Install dependencies in this project, then run npm run migrate:mysql. The importer copies database rows and local files under uploads into PostgreSQL storage. It deliberately leaves the Gmail App Password blank and does not copy old reset tokens; save a new App Password in Admin Settings after the deploy.

Do not paste database URLs, SESSION_SECRET, or Gmail App Passwords into chat or commit them to the project.
