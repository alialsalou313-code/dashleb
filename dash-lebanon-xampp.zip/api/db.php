<?php
declare(strict_types=1);
function cfg(): array { static $c=null; if($c===null)$c=require __DIR__.'/config.php'; return $c; }
function db(): PDO { static $pdo=null; if($pdo===null){$c=cfg();$dsn='mysql:host='.$c['db_host'].';port='.$c['db_port'].';dbname='.$c['db_name'].';charset=utf8mb4';$pdo=new PDO($dsn,$c['db_user'],$c['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]);}return $pdo; }
