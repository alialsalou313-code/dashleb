<?php
declare(strict_types=1);
if (!function_exists('array_is_list')) {
    function array_is_list(array $array): bool {
        $expected = 0;
        foreach ($array as $key => $_value) {
            if ($key !== $expected++) return false;
        }
        return true;
    }
}

ini_set('session.use_strict_mode','1');
session_set_cookie_params(['lifetime'=>0,'path'=>'/dash-lebanon','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','httponly'=>true,'samesite'=>'Lax']);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require __DIR__ . '/db.php';

function out($data=null, ?array $error=null, int $status=200): never {
    http_response_code($status); echo json_encode(['data'=>$data,'error'=>$error], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}
function fail(string $message, int $status=400): never { out(null,['message'=>$message],$status); }
function body(): array { $v=json_decode(file_get_contents('php://input'),true); return is_array($v)?$v:[]; }
function uid(): ?string { return $_SESSION['uid'] ?? null; }
function profile(): ?array { static $p=null; if(!uid())return null; if($p===null){$q=db()->prepare('SELECT * FROM profiles WHERE id=?');$q->execute([uid()]);$p=$q->fetch()?:null;} return $p; }
function admin(): bool { return (profile()['role']??'')==='admin'; }
function requireUser(): string { if(!uid())fail('Please sign in to continue.',401); return uid(); }
function requireAdmin(): void { requireUser(); if(!admin())fail('Administrator access required.',403); }
function uuid(): string { return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',random_int(0,65535),random_int(0,65535),random_int(0,65535),random_int(16384,20479),random_int(32768,49151),random_int(0,65535),random_int(0,65535),random_int(0,65535)); }
function validTable(string $t): string { $allowed=['profiles','settings','categories','products','product_images','wishlists','delivery_locations','orders','order_items','reviews','points_history','contact_messages','coupons','ai_settings','ai_public_settings','mail_settings']; if(!in_array($t,$allowed,true))fail('Unknown table.',404); return $t; }
function schemaColumns(string $table): array { static $cache=[]; if(!isset($cache[$table])){$cache[$table]=array_column(db()->query('DESCRIBE `'.$table.'`')->fetchAll(),'Field');} return $cache[$table]; }
function cleanRow(string $t, array $row): array { $valid=schemaColumns($t);$row=array_intersect_key($row,array_flip($valid));foreach($row as $k=>$v){if(in_array($k,['page_visibility','bundle_items','specifications'],true)&&is_array($v))$row[$k]=json_encode($v,JSON_UNESCAPED_UNICODE);elseif(is_string($v)&&preg_match('/(^|_)(at|date)$/',$k)&&$v!==''){try{$row[$k]=(new DateTimeImmutable($v))->format('Y-m-d H:i:s');}catch(Throwable $e){}}}return $row; }
function whereParts(array $filters,array &$args): string {
 $parts=[];
 foreach($filters as $f){$col=$f['column']??'';$op=$f['op']??'eq';$v=$f['value']??null;
  if(!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/',$col))continue;
  $col='`'.$col.'`';
  if($op==='in'&&is_array($v)){if(!$v){$parts[]='1=0';continue;}$parts[]=$col.' IN ('.implode(',',array_fill(0,count($v),'?')).')';array_push($args,...$v);}
  elseif($op==='is'&&$v===null)$parts[]=$col.' IS NULL';
  elseif(in_array($op,['eq','neq','gt','gte','lt','lte','ilike','like'],true)){$sqlop=['eq'=>'=','neq'=>'<>','gt'=>'>','gte'=>'>=','lt'=>'<','lte'=>'<=','ilike'=>'LIKE','like'=>'LIKE'][$op];$parts[]=$col.' '.$sqlop.' ?';$args[]=$op==='ilike'?str_replace('*','%',(string)$v):$v;}
 }
 return $parts?' WHERE '.implode(' AND ',$parts):'';
}
function relate(string $table,array $rows,string $selection): array {
 preg_match_all('/([A-Za-z_][A-Za-z0-9_]*)\(([^()]*)\)/',$selection,$matches,PREG_SET_ORDER);
 foreach($matches as $m){$rel=$m[1];$wanted=array_values(array_filter(array_map('trim',explode(',',$m[2])),fn($x)=>$x&&$x!=='*'&&preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/',$x)));
  $map=['products'=>['product_images'=>['product_id','many','id']], 'orders'=>['order_items'=>['order_id','many','id']], 'reviews'=>['profiles'=>['id','one','user_id'],'products'=>['id','one','product_id']], 'order_items'=>['products'=>['id','one','product_id']], 'coupons'=>[], 'profiles'=>[]];
  if(!isset($map[$table][$rel]))continue;[$key,$kind,$foreign]=$map[$table][$rel];
  foreach($rows as &$row){$id=$row[$foreign]??null;if(!$id){$row[$rel]=$kind==='many'?[]:null;continue;}$sql='SELECT * FROM `'.$rel.'` WHERE `'.$key.'`=?';if($rel==='product_images')$sql.=' ORDER BY sort_order';$q=db()->prepare($sql);$q->execute([$id]);$found=$q->fetchAll();$found=array_map(function($r)use($wanted){if(!$wanted)return $r;return array_intersect_key($r,array_flip($wanted));},$found);$row[$rel]=$kind==='many'?$found:($found[0]??null);}
  unset($row);
 }
 return $rows;
}
function canRead(string $t): void { if(in_array($t,['settings','categories','products','product_images','ai_public_settings','reviews'],true))return;requireUser();if(in_array($t,['orders','order_items','wishlists','delivery_locations','points_history','profiles'],true))return;requireAdmin(); }
function canWrite(string $t,string $op,array $rows): void {
 if($t==='contact_messages'&&$op==='insert')return;
  if($t==='profiles'&&!admin()&&$op==='update'){requireUser();return;}
  if(in_array($t,['wishlists','delivery_locations'],true)&&!admin())requireUser();
  if($t==='reviews'&&!admin()&&$op==='insert'){requireUser();return;}
 if($t==='orders'&&$op==='select'&&!admin())requireUser();
 if(in_array($t,['wishlists','delivery_locations','reviews'],true)&&!admin())return;
 requireAdmin();
}
function queryRows(array $b): void {
 $t=validTable((string)($b['table']??''));$op=$b['op']??'select';$args=[];$filters=$b['filters']??[];
 if($op==='select'){
  canRead($t);
  if(!admin()){
   if(in_array($t,['orders','wishlists','delivery_locations','points_history'],true))$filters[]=['column'=>'user_id','op'=>'eq','value'=>uid()];
   if($t==='profiles')$filters[]=['column'=>'id','op'=>'eq','value'=>uid()];
   if($t==='reviews')$filters[]=['column'=>'status','op'=>'eq','value'=>'approved'];
   if($t==='order_items'){$filters[]=['column'=>'order_id','op'=>'in','value'=>array_column(db()->query('SELECT id FROM orders WHERE user_id='.db()->quote(uid()))->fetchAll(),'id')];}
  }
  $wh=whereParts($filters,$args);$sql='SELECT * FROM `'.$t.'`'.$wh;
  foreach(($b['order']??[]) as $o){$c=$o['column']??'';if(preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/',$c))$sql.=' ORDER BY `'.$c.'` '.(!empty($o['ascending'])?'ASC':'DESC');}
  if(isset($b['limit']))$sql.=' LIMIT '.max(0,min(1000,(int)$b['limit']));
  $q=db()->prepare($sql);$q->execute($args);$rows=$q->fetchAll();$rows=relate($t,$rows,(string)($b['columns']??'*'));
  if(!empty($b['head'])){$q=db()->prepare('SELECT COUNT(*) FROM `'.$t.'`'.$wh);$q->execute($args);out(['__count'=>(int)$q->fetchColumn()]);}
  if(!empty($b['single'])){if(!$rows)out(null,null);out($rows[0]);} out($rows);
 }
 $rows=$b['rows']??[];if(!is_array($rows))$rows=[];if($rows&&!array_is_list($rows))$rows=[$rows];
 canWrite($t,$op,$rows);
 if($op==='insert'||$op==='upsert'){
  $created=[];foreach($rows as $row){$row=cleanRow($t,is_array($row)?$row:[]);if(!$row)continue;
   if($t==='reviews'&&!admin()){$row['user_id']=requireUser();$row['status']='pending';}
   if($t==='wishlists'&&!admin())$row['user_id']=requireUser();
   if($t==='delivery_locations'&&!admin())$row['user_id']=requireUser();
   if(in_array('id',schemaColumns($t),true)&&empty($row['id']))$row['id']=uuid();
   $cols=array_keys($row);$quoted=array_map(fn($c)=>'`'.$c.'`',$cols);$marks=implode(',',array_fill(0,count($cols),'?'));
   $sql='INSERT INTO `'.$t.'` ('.implode(',',$quoted).') VALUES ('.$marks.')';
   if($op==='upsert')$sql.=' ON DUPLICATE KEY UPDATE '.implode(',',array_map(fn($c)=>'`'.$c.'`=VALUES(`'.$c.'`)',$cols));
   $q=db()->prepare($sql);$q->execute(array_values($row));$created[]=$row;
   }if(!empty($b['single']))out($created[0]??null);out($created);
 }
 if($op==='update'||$op==='delete'){
  if(!admin()){
   if($t==='profiles')$filters[]=['column'=>'id','op'=>'eq','value'=>requireUser()];
   elseif(in_array($t,['wishlists','delivery_locations'],true))$filters[]=['column'=>'user_id','op'=>'eq','value'=>requireUser()];
   elseif($t==='reviews')fail('Administrator access required.',403);
  }
  $wh=whereParts($filters,$args);if(!$wh)fail('A filter is required for this change.',400);
  if($op==='delete'){$q=db()->prepare('DELETE FROM `'.$t.'`'.$wh);$q->execute($args);out(null);}
  $row=cleanRow($t,$rows[0]??[]);unset($row['id'],$row['created_at']);if($t==='profiles'&&!admin())unset($row['role'],$row['account_status'],$row['loyalty_points']);if(!$row)out([]);
  $set=implode(',',array_map(fn($c)=>'`'.$c.'`=?',array_keys($row)));$q=db()->prepare('UPDATE `'.$t.'` SET '.$set.$wh);$q->execute([...array_values($row),...$args]);if($t==='ai_settings'){$pub=db()->prepare('UPDATE ai_public_settings SET enabled=?,assistant_name=?,welcome_message=? WHERE id=1');$pub->execute([$row['enabled']??0,$row['assistant_name']??'المساعد الذكي',$row['welcome_message']??'']);}out([]);
 }
 fail('Unsupported database operation.');
}
function authRoute(array $b): void {
 $action=$b['action']??'';
 if($action==='getSession'){if(!uid())out(['session'=>null]);$p=profile();out(['session'=>['user'=>['id'=>uid(),'email'=>$p['email']??'']]]);}
 if($action==='signOut'){$p=session_get_cookie_params();$_SESSION=[];session_destroy();setcookie(session_name(),'',['expires'=>time()-3600,'path'=>$p['path'],'secure'=>$p['secure'],'httponly'=>true,'samesite'=>'Lax']);out(['ok'=>true]);}
 if($action==='signIn'){$email=strtolower(trim((string)($b['email']??'')));$q=db()->prepare('SELECT * FROM users WHERE email=?');$q->execute([$email]);$u=$q->fetch();if(!$u||!password_verify((string)($b['password']??''),$u['password_hash']))fail('Invalid email or password.',401);$q=db()->prepare('SELECT account_status FROM profiles WHERE id=?');$q->execute([$u['id']]);if(($q->fetchColumn()?:'enabled')!=='enabled')fail('This account is disabled.',403);session_regenerate_id(true);$_SESSION['uid']=$u['id'];out(['session'=>['user'=>['id'=>$u['id'],'email'=>$u['email']]]]);}
 if($action==='signUp'){$email=strtolower(trim((string)($b['email']??'')));$password=(string)($b['password']??'');$meta=$b['data']??[];if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<6)fail('Enter a valid email and a password of at least 6 characters.');$id=uuid();$pdo=db();try{$pdo->beginTransaction();$q=$pdo->prepare('INSERT INTO users(id,email,password_hash) VALUES(?,?,?)');$q->execute([$id,$email,password_hash($password,PASSWORD_DEFAULT)]);$q=$pdo->prepare('INSERT INTO profiles(id,email,first_name,last_name,username,phone) VALUES(?,?,?,?,?,?)');$q->execute([$id,$email,$meta['first_name']??'', $meta['last_name']??'', $meta['username']??null, $meta['phone']??null]);$pdo->commit();session_regenerate_id(true);$_SESSION['uid']=$id;out(['session'=>['user'=>['id'=>$id,'email'=>$email]]]);}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();fail('Account could not be created. The email or username may already be in use.',409);}}
 if($action==='resetPassword'){require __DIR__.'/mail.php';try{issuePasswordReset((string)($b['email']??''));}catch(Throwable $e){error_log('Password reset email failed: '.$e->getMessage());}out(['ok'=>true,'message'=>'If that account exists, a reset link has been sent.']);}
 fail('Unsupported authentication action.',404);
}
function rpc(array $b): void {
 $name=$b['name']??'';$a=$b['args']??[];
 if($name==='validate_coupon'){$code=strtoupper(trim((string)($a['p_code']??'')));$q=db()->prepare('SELECT * FROM coupons WHERE code=? AND is_active=1 AND (starts_at IS NULL OR starts_at<=NOW()) AND (expires_at IS NULL OR expires_at>NOW())');$q->execute([$code]);$c=$q->fetch();$sub=(float)($a['p_subtotal']??0);if(!$c||$sub<(float)$c['min_subtotal']||($c['max_uses']!==null&&(int)$c['used_count']>=(int)$c['max_uses']))out(null);if(uid()&&$c['max_uses_per_user']!==null){$q=db()->prepare('SELECT COUNT(*) FROM coupon_redemptions WHERE coupon_id=? AND user_id=?');$q->execute([$c['id'],uid()]);if((int)$q->fetchColumn()>=(int)$c['max_uses_per_user'])out(null);}$d=$c['discount_type']==='percent'?$sub*(float)$c['discount_value']/100:(float)$c['discount_value'];if($c['max_discount']!==null)$d=min($d,(float)$c['max_discount']);out(round(min($sub,$d),2));}
 if($name==='place_order'){$items=$a['p_items']??[];$info=$a['p_info']??[];if(!$items||empty($info['name'])||empty($info['phone'])||empty($info['city'])||empty($info['address']))fail('Order details are incomplete.');$pdo=db();$pdo->beginTransaction();try{$subtotal=0;$picked=[];foreach($items as $it){$q=$pdo->prepare('SELECT id,name,price,bundle_price,is_active FROM products WHERE id=?');$q->execute([$it['product_id']??'']);$p=$q->fetch();$qty=max(1,min(50,(int)($it['qty']??1)));$bundle=!empty($it['is_bundle']);if(!$p||!$p['is_active'])throw new RuntimeException('A product is no longer available.');$price=$bundle&&$p['bundle_price']!==null?(float)$p['bundle_price']:(float)$p['price'];$subtotal+=$bundle?$price:$price*$qty;$picked[]=[$p,$qty,$bundle,$price];}$discount=0;$coupon=strtoupper(trim((string)($a['p_coupon']??'')));$c=null;if($coupon){$q=$pdo->prepare('SELECT * FROM coupons WHERE code=? AND is_active=1 AND (starts_at IS NULL OR starts_at<=NOW()) AND (expires_at IS NULL OR expires_at>NOW()) FOR UPDATE');$q->execute([$coupon]);$c=$q->fetch();if(!$c||$subtotal<(float)$c['min_subtotal']||($c['max_uses']!==null&&(int)$c['used_count']>=(int)$c['max_uses']))throw new RuntimeException('invalid_coupon');if(uid()&&$c['max_uses_per_user']!==null){$q=$pdo->prepare('SELECT COUNT(*) FROM coupon_redemptions WHERE coupon_id=? AND user_id=?');$q->execute([$c['id'],uid()]);if((int)$q->fetchColumn()>=(int)$c['max_uses_per_user'])throw new RuntimeException('coupon_limit_reached');}$discount=$c['discount_type']==='percent'?$subtotal*(float)$c['discount_value']/100:(float)$c['discount_value'];if($c['max_discount']!==null)$discount=min($discount,(float)$c['max_discount']);$discount=min($subtotal,$discount);$pdo->prepare('UPDATE coupons SET used_count=used_count+1 WHERE id=?')->execute([$c['id']]);}$id=uuid();$number='DL-'.date('ymd').'-'.strtoupper(substr(str_replace('-','',$id),0,6));$user=uid();$delivery=4.0;$total=max(0,$subtotal+$delivery-$discount);$q=$pdo->prepare('INSERT INTO orders(id,order_number,user_id,name,phone,phone2,city,district,address,floor,notes,subtotal,delivery_fee,discount,total,coupon_code,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');$q->execute([$id,$number,$user,$info['name'],$info['phone'],$info['phone2']??null,$info['city'],$info['district']??null,$info['address'],$info['floor']??null,$info['notes']??null,$subtotal,$delivery,$discount,$total,$coupon?:null,'pending']);$ins=$pdo->prepare('INSERT INTO order_items(order_id,product_id,product_name,qty,price,is_bundle) VALUES(?,?,?,?,?,?)');foreach($picked as [$p,$qty,$bundle,$price])$ins->execute([$id,$p['id'],$p['name'],$qty,$price,$bundle]);if($c){$pdo->prepare('INSERT INTO coupon_redemptions(coupon_id,user_id,order_id,code) VALUES(?,?,?,?)')->execute([$c['id'],$user,$id,$coupon]);}$q=$pdo->query('SELECT points_per_dollar FROM settings WHERE id=1');$rate=(float)($q->fetchColumn()?:0);$earned=$user?(int)floor($total*$rate):0;if($earned>0){$pdo->prepare('UPDATE profiles SET loyalty_points=loyalty_points+? WHERE id=?')->execute([$earned,$user]);$pdo->prepare('INSERT INTO points_history(user_id,points,description,order_id) VALUES(?,?,?,?)')->execute([$user,$earned,'Points earned from order '.$number,$id]);}$pdo->commit();out(['order_number'=>$number,'points_earned'=>$earned]);}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();fail(in_array($e->getMessage(),['invalid_coupon','coupon_limit_reached'],true)?$e->getMessage():'Could not place order.',400);}}
 if($name==='cancel_order'){requireUser();$id=$a['p_order']??'';$sql='SELECT * FROM orders WHERE id=?'.(admin()?'':' AND user_id=?').' FOR UPDATE';$pdo=db();$pdo->beginTransaction();try{$q=$pdo->prepare($sql);$q->execute(admin()?[$id]:[$id,uid()]);$o=$q->fetch();if(!$o||$o['status']!=='pending')throw new RuntimeException('This order can no longer be cancelled.');$pdo->prepare('UPDATE orders SET status=?,cancel_reason=? WHERE id=?')->execute(['cancelled',$a['p_reason']??null,$id]);$pdo->commit();out(true);}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();fail($e->getMessage());}}
 if($name==='admin_list_users'){requireAdmin();out(db()->query('SELECT id,email,first_name,last_name,username,phone,role,account_status,loyalty_points,created_at FROM profiles ORDER BY created_at DESC')->fetchAll());}
 if($name==='admin_set_account_status'){requireAdmin();$q=db()->prepare('UPDATE profiles SET account_status=? WHERE id=?');$q->execute([$a['p_status']??'enabled',$a['p_user_id']??'']);out(true);}
 if($name==='admin_update_credentials'){requireAdmin();$email=strtolower(trim((string)($a['p_email']??'')));$password=(string)($a['p_password']??'');if(!filter_var($email,FILTER_VALIDATE_EMAIL))fail('Enter a valid email address.');if($password!==''&&strlen($password)<8)fail('Password must have at least 8 characters.');$pdo=db();try{$pdo->beginTransaction();$pdo->prepare('UPDATE users SET email=?,password_hash=CASE WHEN ?<>? THEN ? ELSE password_hash END WHERE id=?')->execute([$email,$password,'',$password!==''?password_hash($password,PASSWORD_DEFAULT):'',$uid()]);$pdo->prepare('UPDATE profiles SET email=? WHERE id=?')->execute([$email,$uid()]);$pdo->commit();out(true);}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();fail('Could not update admin login. The email may already be in use.',409);}}
 if($name==='admin_get_mail_settings'){requireAdmin();$m=db()->query('SELECT sender_email,smtp_username,smtp_host,smtp_port,app_url,reset_subject,reset_message,reset_ttl_minutes FROM mail_settings WHERE id=1')->fetch();$m['has_password']=(bool)db()->query('SELECT (LENGTH(smtp_app_password)>0) FROM mail_settings WHERE id=1')->fetchColumn();out($m);}
 if($name==='admin_save_mail_settings'){requireAdmin();$email=strtolower(trim((string)($a['p_sender_email']??'')));$pass=(string)($a['p_app_password']??'');$host=trim((string)($a['p_smtp_host']??'smtp.gmail.com'));$port=(int)($a['p_smtp_port']??587);$appUrl=rtrim(trim((string)($a['p_app_url']??'')),'/');$subject=trim((string)($a['p_reset_subject']??''));$message=trim((string)($a['p_reset_message']??''));$ttl=(int)($a['p_reset_ttl_minutes']??30);if(!filter_var($email,FILTER_VALIDATE_EMAIL))fail('Enter a valid sender email.');if(!preg_match('/^[a-z0-9.-]+$/i',$host)||$port<1||$port>65535)fail('Check the SMTP server and port.');if(!filter_var($appUrl,FILTER_VALIDATE_URL)||!in_array(strtolower((string)parse_url($appUrl,PHP_URL_SCHEME)),['http','https'],true))fail('Enter a valid website URL.');if($subject===''||mb_strlen($subject)>200)fail('Email subject must be 1 to 200 characters.');if($ttl<5||$ttl>1440)fail('Link expiry must be between 5 and 1440 minutes.');if($pass!==''&&strlen(preg_replace('/\s+/','',$pass))<12)fail('Check the Gmail App Password and try again.');$sql='UPDATE mail_settings SET sender_email=?,smtp_username=?,smtp_host=?,smtp_port=?,app_url=?,reset_subject=?,reset_message=?,reset_ttl_minutes=?';$args=[$email,$email,$host,$port,$appUrl,$subject,$message,$ttl];if($pass!==''){$sql.=',smtp_app_password=?';$args[]=preg_replace('/\s+/','',$pass);}$sql.=' WHERE id=1';db()->prepare($sql)->execute($args);$m=db()->query('SELECT sender_email,smtp_host,smtp_port,app_url,reset_subject,reset_message,reset_ttl_minutes,(LENGTH(smtp_app_password)>0) AS has_password FROM mail_settings WHERE id=1')->fetch();$m['has_password']=(bool)$m['has_password'];out($m);}
 if($name==='admin_set_user_password'){requireAdmin();$target=(string)($a['p_user_id']??'');$password=(string)($a['p_password']??'');if(!$target||$target===uid())fail('Choose a different customer account.');if(strlen($password)<10)fail('Temporary password must have at least 10 characters.');$q=db()->prepare('UPDATE users SET password_hash=? WHERE id=?');$q->execute([password_hash($password,PASSWORD_DEFAULT),$target]);if(!$q->rowCount())fail('Customer account was not found.',404);out(true);}
 if($name==='admin_save_coupon'){requireAdmin();$c=$a['p_coupon']??[];$id=$a['p_id']?:uuid();$row=['id'=>$id,'code'=>strtoupper(trim((string)($c['code']??''))),'description'=>$c['description']??null,'discount_type'=>$c['discount_type']??'fixed','discount_value'=>(float)($c['discount_value']??0),'min_subtotal'=>(float)($c['min_subtotal']??0),'max_discount'=>$c['max_discount']??null,'max_uses'=>$c['max_uses']??null,'max_uses_per_user'=>$c['max_uses_per_user']??null,'starts_at'=>$c['starts_at']??null,'expires_at'=>$c['expires_at']??null,'is_active'=>!empty($c['is_active'])];$cols=array_keys($row);$sql='INSERT INTO coupons (`'.implode('`,`',$cols).'`) VALUES ('.implode(',',array_fill(0,count($cols),'?')).') ON DUPLICATE KEY UPDATE '.implode(',',array_map(fn($x)=>"`$x`=VALUES(`$x`)",array_slice($cols,1)));db()->prepare($sql)->execute(array_values($row));out($id);}
 if($name==='admin_toggle_coupon'){requireAdmin();db()->prepare('UPDATE coupons SET is_active=? WHERE id=?')->execute([!empty($a['p_active']),$a['p_id']??'']);out(true);}
 fail('REST function not implemented: '.$name,501);
}
function safeStoragePath(string $p): string {$p=str_replace('\\','/',$p);$parts=explode('/',$p);if(!$p||count($parts)>8||in_array('..',$parts,true))fail('Invalid storage path.');foreach($parts as $part)if(!preg_match('/^[A-Za-z0-9_.-]{1,120}$/',$part)||$part==='.')fail('Invalid storage path.');return implode('/',$parts);}
function uploadFile(array $b): void {$bucket=preg_replace('/[^a-z0-9_-]/i','',(string)($b['bucket']??''));$rel=safeStoragePath((string)($b['path']??''));$data=$b['data']??'';$mime=(string)($b['mime']??'');if($bucket==='contact-voice'){if(!in_array($mime,['audio/webm','audio/ogg','audio/mp4','audio/mpeg'],true))fail('Unsupported voice recording format.',415);}else{requireAdmin();if(!in_array($mime,['image/jpeg','image/png','image/webp','image/gif','image/avif'],true))fail('Only common image formats are allowed.',415);}if(!$bucket||!is_string($data))fail('Invalid upload.');$raw=base64_decode(preg_replace('#^data:[^,]+,#','',$data),true);if($raw===false||strlen($raw)>12*1024*1024)fail('Upload is invalid or exceeds 12 MB.');$dir=cfg()['uploads_dir'].'/'.$bucket.'/'.dirname($rel);if(!is_dir($dir))mkdir($dir,0775,true);$target=cfg()['uploads_dir'].'/'.$bucket.'/'.$rel;if(file_exists($target))fail('A file with that name already exists.',409);if(file_put_contents($target,$raw)===false)fail('Could not save uploaded file.',500);$url=cfg()['base_url'].'/uploads/'.$bucket.'/'.$rel;out(['path'=>$rel,'publicUrl'=>$url,'signedUrl'=>$url]);}
function removeFiles(array $b): void {requireAdmin();$bucket=preg_replace('/[^a-z0-9_-]/i','',(string)($b['bucket']??''));$deleted=[];foreach(($b['paths']??[]) as $p){$rel=safeStoragePath((string)$p);$file=cfg()['uploads_dir'].'/'.$bucket.'/'.$rel;if(is_file($file)){unlink($file);$deleted[]=$rel;}}out($deleted);}
function aiFunction(string $name,array $b): void {
 if($name!=='ai-chat')fail('Unknown server function.',404);$action=$b['action']??'chat';if($action==='test')requireAdmin();$s=db()->query('SELECT * FROM ai_settings WHERE id=1')->fetch();
 if(!$s)fail('AI settings have not been initialized.',503);if($action!=='test'&&!$s['enabled'])fail('The AI assistant is disabled.',503);
 $key='';
 if($action==='test'&&!empty($b['api_key']))$key=(string)$b['api_key'];else $key=(string)($s['api_key']??'');
 $provider=$action==='test'?($b['provider']??$s['provider']):$s['provider'];$model=$action==='test'?($b['model_name']??$s['model_name']):$s['model_name'];$url=trim((string)($action==='test'?($b['api_url']??$s['api_url']):$s['api_url']));
 if(!$key){if($action==='test')out(['ok'=>false,'reason'=>'missing_api_key']);fail('AI provider API key is missing.',503);}if(!$model){if($action==='test')out(['ok'=>false,'reason'=>'missing_model']);fail('AI model is not configured.',503);}
 if(!$url)$url=$provider==='anthropic'?'https://api.anthropic.com/v1/messages':'https://api.openai.com/v1/chat/completions';elseif($provider!=='anthropic'&&!str_ends_with($url,'/chat/completions'))$url=rtrim($url,'/').'/chat/completions';
 $system=trim((string)($s['system_instructions']??''))?:'You are the Dash Lebanon store assistant. Answer clearly using the supplied store context.';$ctx=$b['clientContext']??[];if($ctx)$system.="\n\nStore context: ".json_encode($ctx,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$messages=[['role'=>'system','content'=>$system]];$chatKey=hash('sha256',(string)($b['sessionId']??$b['conversationId']??'guest'));
 if($action!=='test'){$history=$_SESSION['ai_history'][$chatKey]??[];foreach(array_slice($history,-10) as $m)$messages[]=$m;$msg=(string)($b['message']??'');$parts=[['type'=>'text','text'=>$msg]];foreach(array_slice($b['images']??[],0,4) as $im){if(preg_match('#^data:(image/[a-zA-Z0-9.+-]+);base64,(.+)$#',(string)($im['dataUrl']??''),$m))$parts[]=$provider==='anthropic'?['type'=>'image','source'=>['type'=>'base64','media_type'=>$m[1],'data'=>$m[2]]]:['type'=>'image_url','image_url'=>['url'=>$im['dataUrl']]];}$messages[]=['role'=>'user','content'=>count($parts)>1?$parts:$msg];}
 if(!function_exists('curl_init')){if($action==='test')out(['ok'=>false,'reason'=>'network_error','message'=>'PHP cURL extension is not enabled.']);fail('PHP cURL is required for AI features.',503);}
 if($provider==='anthropic'){$headers=['Content-Type: application/json','x-api-key: '.$key,'anthropic-version: 2023-06-01'];$payload=['model'=>$model,'max_tokens'=>min(2000,max(64,(int)$s['max_tokens'])),'system'=>$system,'messages'=>array_values(array_filter($messages,fn($m)=>$m['role']!=='system'))];}else{$headers=['Content-Type: application/json','Authorization: Bearer '.$key];$payload=['model'=>$model,'temperature'=>(float)$s['temperature'],'max_tokens'=>min(2000,max(64,(int)$s['max_tokens'])),'messages'=>$messages];}
 $ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>45,CURLOPT_CONNECTTIMEOUT=>12]);$raw=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$curlError=curl_error($ch);curl_close($ch);$res=is_string($raw)?json_decode($raw,true):null;
 if($status<200||$status>=300||!is_array($res)){if($action==='test')out(['ok'=>false,'reason'=>$status===401?'unauthorized':($status===429?'rate_limited':'provider_error'),'http_status'=>$status,'message'=>$curlError?:($res['error']['message']??'Provider did not return valid JSON.')]);fail('AI provider request failed.'.($status?' HTTP '.$status:''),502);}if($action==='test')out(['ok'=>true,'provider'=>$provider,'model'=>$model]);$reply=$provider==='anthropic'?($res['content'][0]['text']??''):($res['choices'][0]['message']['content']??'');if(is_array($reply))$reply=implode("\n",array_map(fn($x)=>$x['text']??'',$reply));$reply=(string)$reply;$_SESSION['ai_history'][$chatKey]=array_slice([...($_SESSION['ai_history'][$chatKey]??[]),['role'=>'user','content'=>(string)($b['message']??'')],['role'=>'assistant','content'=>$reply]],-10);out(['reply'=>$reply,'conversationId'=>$b['conversationId']??null,'productIds'=>[],'offerOrder'=>false]);
}

try{
 $resource=trim((string)($_GET['resource']??''),'/');
 if($resource!==''){
  $method=$_SERVER['REQUEST_METHOD']??'GET';$parts=$resource===''?[]:explode('/',$resource);
  if(($parts[0]??'')==='health'){try{db()->query('SELECT 1');out(['status'=>'ok','database'=>'connected']);}catch(Throwable $e){out(['status'=>'error','database'=>'unavailable'],['message'=>'Database connection failed.'],503);}}
  if(($parts[0]??'')==='auth'){$action=['session'=>'getSession','login'=>'signIn','register'=>'signUp','logout'=>'signOut','reset-password'=>'resetPassword'][$parts[1]??'']??'';$b=body();$b=['route'=>'auth','action'=>$action,'email'=>$b['email']??'','password'=>$b['password']??'','data'=>$b['data']??[]];authRoute($b);}
  if(($parts[0]??'')==='rpc'&&isset($parts[1])){$b=body();rpc(['name'=>$parts[1],'args'=>$b]);}
  if(($parts[0]??'')==='orders'&&$method==='POST'&&count($parts)===1){$b=body();rpc(['name'=>'place_order','args'=>['p_items'=>$b['items']??[],'p_info'=>$b['info']??[],'p_coupon'=>$b['coupon']??null]]);}
  if(($parts[0]??'')==='orders'&&($parts[2]??'')==='cancel'&&$method==='POST'){$b=body();rpc(['name'=>'cancel_order','args'=>['p_order'=>$parts[1]??'','p_reason'=>$b['reason']??null]]);}
  $table=validTable($parts[0]??'');$filters=[];if(isset($parts[1]))$filters[]=['column'=>'id','op'=>'eq','value'=>$parts[1]];
  foreach($_GET as $key=>$value){if($key==='resource'||!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/',$key))continue;$v=explode('.',(string)$value,2);$op=count($v)>1?$v[0]:'eq';$filters[]=['column'=>$key,'op'=>$op,'value'=>$v[count($v)-1]];}
  $b=body();$op=['GET'=>'select','POST'=>'insert','PATCH'=>'update','PUT'=>'upsert','DELETE'=>'delete'][$method]??'';if(!$op)fail('Method not allowed.',405);queryRows(['table'=>$table,'op'=>$op,'rows'=>$op==='insert'||$op==='upsert'?($b['rows']??$b):[$b],'filters'=>$filters,'columns'=>'*','limit'=>isset($_GET['limit'])?(int)$_GET['limit']:null]);
 }
 $b=body();$route=$b['route']??'db';if($route==='auth')authRoute($b);if($route==='rpc')rpc($b);if($route==='upload')uploadFile($b);if($route==='remove')removeFiles($b);if($route==='function')aiFunction((string)($b['name']??''),$b['body']??[]);queryRows($b);
}catch(Throwable $e){error_log('Dash API: '.$e->getMessage());out(null,['message'=>'Server error. Check the PHP error log.'],500);}
