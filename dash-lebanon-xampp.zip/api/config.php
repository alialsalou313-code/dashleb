<?php
declare(strict_types=1);
// Local XAMPP defaults. Change these if your MySQL root account has a password.
return [
    'db_host' => '127.0.0.1', 'db_port' => 3306,
    'db_name' => 'dash_lebanon', 'db_user' => 'root', 'db_pass' => '',
    'uploads_dir' => dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads',
    'base_url' => '/dash-lebanon',
    'app_url' => 'http://localhost/dash-lebanon',
];
