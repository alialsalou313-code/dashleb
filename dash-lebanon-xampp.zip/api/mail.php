<?php
declare(strict_types=1);
require_once __DIR__.'/db.php';
function smtpRead($s): string {$out='';do{$line=fgets($s,515);if($line===false)throw new RuntimeException('Gmail SMTP closed the connection.');$out.=$line;}while(strlen($line)>=4&&$line[3]==='-');$code=(int)substr($out,0,3);if($code<200||$code>=400)throw new RuntimeException('SMTP rejected a command ('.$code.').');return $out;}
function smtpCommand($s,string $command): string {fwrite($s,$command."\r\n");return smtpRead($s);}
function sendLocalMail(string $to,string $subject,string $textHtml,string $textPlain): void {
 $m=db()->query('SELECT * FROM mail_settings WHERE id=1')->fetch();if(!$m||trim((string)$m['smtp_app_password'])==='')throw new RuntimeException('Email sender is not configured.');
 $user=(string)$m['smtp_username'];$pass=preg_replace('/\s+/','',(string)$m['smtp_app_password']);$from=(string)$m['sender_email'];$host=(string)$m['smtp_host'];$port=(int)$m['smtp_port'];$errno=0;$err='';
 $s=stream_socket_client('tcp://'.$host.':'.$port,$errno,$err,20,STREAM_CLIENT_CONNECT);if(!$s)throw new RuntimeException('Could not connect to Gmail SMTP.');stream_set_timeout($s,20);
 try {smtpRead($s);smtpCommand($s,'EHLO localhost');smtpCommand($s,'STARTTLS');if(!stream_socket_enable_crypto($s,true,STREAM_CRYPTO_METHOD_TLS_CLIENT))throw new RuntimeException('Could not start TLS for Gmail SMTP.');smtpCommand($s,'EHLO localhost');smtpCommand($s,'AUTH LOGIN');smtpCommand($s,base64_encode($user));smtpCommand($s,base64_encode($pass));smtpCommand($s,'MAIL FROM:<'.$from.'>');smtpCommand($s,'RCPT TO:<'.$to.'>');smtpCommand($s,'DATA');
  $boundary='dash_'.bin2hex(random_bytes(12));$safeSubject='=?UTF-8?B?'.base64_encode($subject).'?=';$headers='From: Dash Lebanon <'.$from.">\r\nTo: ".$to."\r\nSubject: ".$safeSubject."\r\nMIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=\"".$boundary."\"\r\n\r\n";
  $body=$headers.'--'.$boundary."\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($textPlain)).'--'.$boundary."\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($textHtml)).'--'.$boundary."--\r\n";$body=preg_replace('/(^|\r\n)\./','$1..',$body);fwrite($s,$body."\r\n.\r\n");smtpRead($s);smtpCommand($s,'QUIT');
 } finally {fclose($s);}
}
function issuePasswordReset(string $email): void {
 $email=strtolower(trim($email));if(!filter_var($email,FILTER_VALIDATE_EMAIL))return;
 $q=db()->prepare('SELECT id FROM users WHERE LOWER(email)=? LIMIT 1');$q->execute([$email]);$user=$q->fetch();if(!$user)return;
 $m=db()->query('SELECT * FROM mail_settings WHERE id=1')->fetch();if(!$m||trim((string)$m['smtp_app_password'])==='')throw new RuntimeException('Email sender is not configured.');
 $ttl=max(5,min(1440,(int)($m['reset_ttl_minutes']??30)));$token=bin2hex(random_bytes(32));$hash=hash('sha256',$token);$expires=(new DateTimeImmutable())->modify('+'.$ttl.' minutes')->format('Y-m-d H:i:s');db()->prepare('REPLACE INTO password_reset_tokens(email,token_hash,expires_at) VALUES(?,?,?)')->execute([$email,$hash,$expires]);
 $url=rtrim((string)($m['app_url']??''),'/').'/reset-password.php?token='.rawurlencode($token);if(!preg_match('~^https?://~i',$url))throw new RuntimeException('Reset website URL is not configured.');
 $subject=trim((string)($m['reset_subject']??''))?:'Reset your Dash Lebanon password';$message=trim((string)($m['reset_message']??''))?:'We received a request to reset your password. Use the button below to choose a new password.';$safeMessage=nl2br(htmlspecialchars($message,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'));$safeUrl=htmlspecialchars($url,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
 $html='<!doctype html><html><body style="margin:0;background:#f5f6f8;font-family:Arial,sans-serif;color:#222"><div style="max-width:560px;margin:32px auto;padding:32px;background:#fff;border-radius:14px"><h2>Reset your Dash Lebanon password</h2><p>'.$safeMessage.'</p><p style="margin:28px 0"><a href="'.$safeUrl.'" style="display:inline-block;padding:14px 24px;background:#e85d3f;color:#fff;text-decoration:none;border-radius:8px;font-weight:bold">Reset password</a></p><p>This link expires in '.$ttl.' minutes. If you did not request this, you can ignore this email.</p><p style="font-size:12px;color:#777;word-break:break-all">If the button does not work, copy this link:<br>'.$safeUrl.'</p></div></body></html>';
 $plain="We received a request to reset your password.\n\n".$message."\n\nReset password: ".$url."\n\nThis link expires in ".$ttl." minutes. If you did not request this, ignore this email.";
 try {sendLocalMail($email,$subject,$html,$plain);}catch(Throwable $e){db()->prepare('DELETE FROM password_reset_tokens WHERE email=? AND token_hash=?')->execute([$email,$hash]);throw $e;}
}
