<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require __DIR__.'/mail.php';
$b=json_decode(file_get_contents('php://input'),true)??[];
try{issuePasswordReset((string)($b['email']??''));echo json_encode(['message'=>'If that account exists, a password reset link has been sent.'],JSON_UNESCAPED_UNICODE);}catch(Throwable $e){error_log('Password reset email failed: '.$e->getMessage());echo json_encode(['message'=>'If that account exists, a reset link has been sent.'],JSON_UNESCAPED_UNICODE);}
