<?php
declare(strict_types=1);
session_start();
require __DIR__.'/../api/db.php';
$message='';$error='';$allowed=['categories','profiles','products','product_images','settings','ai_public_settings','delivery_locations','orders','order_items','wishlists','reviews','points_history','coupons','contact_messages'];
$q=isset($_SESSION['uid'])?db()->prepare('SELECT role FROM profiles WHERE id=?'):null;if($q){$q->execute([$_SESSION['uid']]);$isAdmin=$q->fetchColumn()==='admin';}else $isAdmin=false;
if(!$isAdmin){http_response_code(403);exit('Administrator login required. Sign in to the store in another tab, then open this page again.');}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $table=(string)($_POST['table']??'');$file=$_FILES['dump']??null;
 if(!in_array($table,$allowed,true))$error='Choose a supported table.';
 elseif(!$file||$file['error']!==UPLOAD_ERR_OK)$error='Choose a CSV or JSON export file.';
 elseif($file['size']>8*1024*1024)$error='File is larger than 8 MB.';
 else try{
  $raw=file_get_contents($file['tmp_name']);$ext=strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));
  if($ext==='json'){$rows=json_decode($raw,true,512,JSON_THROW_ON_ERROR);if(!is_array($rows)||!array_is_list($rows))throw new RuntimeException('JSON must contain an array of row objects.');}
  else{$stream=fopen($file['tmp_name'],'rb');$header=fgetcsv($stream);if(!$header)throw new RuntimeException('CSV header row is missing.');$header=array_map(fn($v)=>trim((string)$v,"\xEF\xBB\xBF \t\n\r\0\x0B\""),$header);$rows=[];while(($values=fgetcsv($stream))!==false){if(count($values)!==count($header))continue;$rows[]=array_combine($header,$values);}fclose($stream);}
  if(count($rows)>10000)throw new RuntimeException('Import is limited to 10,000 rows per file.');
  $pdo=db();$pdo->beginTransaction();$inserted=0;
  foreach($rows as $record){if(!is_array($record))continue;$row=array_intersect_key($record,array_flip(array_column($pdo->query('DESCRIBE `'.$table.'`')->fetchAll(),'Field')));unset($row['password'],$row['password_hash']);
   foreach($row as $key=>$value){if($value===''){$row[$key]=null;continue;}if(in_array($key,['is_active','is_featured','is_bundle','is_read','enabled'],true))$row[$key]=in_array(strtolower((string)$value),['1','true','yes'],true)?1:0;if(in_array($key,['page_visibility','bundle_items'],true)&&is_string($value)){$decoded=json_decode($value,true);$row[$key]=$decoded===null?null:json_encode($decoded,JSON_UNESCAPED_UNICODE);}}
   if($table==='profiles'){$id=(string)($row['id']??'');$email=strtolower((string)($row['email']??''));if(!$id||!filter_var($email,FILTER_VALIDATE_EMAIL))continue;$placeholder=password_hash(bin2hex(random_bytes(32)),PASSWORD_DEFAULT);$u=$pdo->prepare('INSERT IGNORE INTO users(id,email,password_hash) VALUES(?,?,?)');$u->execute([$id,$email,$placeholder]);}
   if(!$row)continue;$cols=array_keys($row);$sql='INSERT INTO `'.$table.'` (`'.implode('`,`',$cols).'`) VALUES ('.implode(',',array_fill(0,count($cols),'?')).')';$pdo->prepare($sql)->execute(array_values($row));$inserted++;
  }
  $pdo->commit();$message="Imported $inserted rows into $table. Remove this importer when migration is finished.";
 }catch(Throwable $e){if(isset($pdo)&&$pdo->inTransaction())$pdo->rollBack();$error='Import failed: '.$e->getMessage();}
}
?><!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Import Supabase data</title><style>body{font:16px system-ui;background:#f2f5fb;color:#182238;max-width:640px;margin:8vh auto;padding:20px}.card{background:white;padding:26px;border-radius:16px;box-shadow:0 10px 40px #1b31511a}label{display:block;margin:14px 0 6px}select,input,button{font:inherit;padding:10px;border:1px solid #ccd4e0;border-radius:8px}input,select{width:100%;box-sizing:border-box}button{margin-top:16px;background:#2952e3;border:0;color:white} .ok{background:#e8f8ee;padding:12px}.err{background:#fee;padding:12px}</style><main class="card"><h1>Import exported data</h1><p>Imports CSV or JSON rows into the selected local table. Sign in as admin first.</p><?php if($message):?><p class="ok"><?=htmlspecialchars($message,ENT_QUOTES,'UTF-8')?></p><?php endif;?><?php if($error):?><p class="err"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></p><?php endif;?><form method="post" enctype="multipart/form-data"><label>Table</label><select name="table"><?php foreach($allowed as $t):?><option><?=htmlspecialchars($t)?></option><?php endforeach;?></select><label>CSV or JSON file</label><input type="file" name="dump" accept=".csv,.json" required><button>Import rows</button></form></main></html>
