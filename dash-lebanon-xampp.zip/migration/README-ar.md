# نقل قاعدة Supabase القديمة

الملف المحفوظ من المتصفح لا يحتوي قاعدة البيانات. من لوحة Supabase القديمة صدّر الجداول إلى CSV، ثم استورد بيانات كل جدول بعد تشغيل `database/schema.sql` عبر phpMyAdmin. ابدأ بهذا الترتيب لتفادي العلاقات: `categories`, `users/profiles`, `products`, `product_images`, `orders`, `order_items`, ثم `wishlists`, `reviews`, `delivery_locations`, `points_history`, `coupons`, `contact_messages`, و`settings`.

صدّر جدول `profiles` ثم استورده أولًا عبر صفحة `migration/import.php` بعد تسجيل الدخول كمدير. ستنشئ الأداة حسابات محلية بمعرّفات العملاء نفسها وكلمات مرور عشوائية لا يعرفها أحد، للمحافظة على ربط الطلبات والمفضّلة. لا تستورد كلمات مرور Supabase؛ عيّن كلمة مرور مؤقتة لكل عميل من لوحة الإدارة وشاركها معه خارج الموقع. لا تضع مفاتيح `service_role` أو كلمات مرور في ملفات الموقع.

يمكن استخدام صفحة `import.php` لتحميل ملف JSON واحد يحتوي مصفوفة سجلات أو ملف CSV من Supabase، مع حذف صفحة الاستيراد بعد الانتهاء. الأداة لا تستورد ملفات Supabase Storage.
